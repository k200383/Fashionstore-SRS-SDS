<?php
include("header.php");
// require_once 'connection.php';
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "fashionstore";

$conn = mysqli_connect($servername, $username, $password, $db_name);
if ($conn-> connect_error)
{
    die("connection failed:".$conn->connect_error);
}
// else
// {
//     echo("connected");
// }

session_start();
$username = $_SESSION['username'];

$name = $_GET['name'];
unset($_SESSION['cart'][$name]);

$sql = "delete from wishlist where ProductName = '$name'";
    if(mysqli_query($conn, $sql)){
        $_SESSION['delete'] = "Deleted $id";
    }
    else{
        $_SESSION['delete'] = "couldn't delete";
    }
header("Location:wishlist.php");

?>