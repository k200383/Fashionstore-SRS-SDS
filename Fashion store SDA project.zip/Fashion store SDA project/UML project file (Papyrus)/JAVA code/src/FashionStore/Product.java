package FashionStore;

public class Product {

	/**
	 * 
	 */
	public String product_name;
	/**
	 * 
	 */
	public String image;
	/**
	 * 
	 */
	public Integer price;
	/**
	 * Getter of product_name
	 */
	public String getProduct_name() {
	 	 return product_name; 
	}
	/**
	 * Setter of product_name
	 */
	public void setProduct_name(String product_name) { 
		 this.product_name = product_name; 
	}
	/**
	 * Getter of image
	 */
	public String getImage() {
	 	 return image; 
	}
	/**
	 * Setter of image
	 */
	public void setImage(String image) { 
		 this.image = image; 
	}
	/**
	 * Getter of price
	 */
	public Integer getPrice() {
	 	 return price; 
	}
	/**
	 * Setter of price
	 */
	public void setPrice(Integer price) { 
		 this.price = price; 
	}
	/**
	 * 
	 */
	public void updateproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void viewproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void addproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void deleteproduct() { 
		// TODO Auto-generated method
	 } 

}
