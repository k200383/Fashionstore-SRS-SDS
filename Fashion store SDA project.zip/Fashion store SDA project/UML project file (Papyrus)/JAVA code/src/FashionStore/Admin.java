package FashionStore;

public class Admin extends User {

	/**
	 * 
	 */
	public String username;
	/**
	 * 
	 */
	public String email;
	/**
	 * 
	 */
	private String password;
	/**
	 * 
	 */
	public String adminID;
	/**
	 * Getter of username
	 */
	public String getUsername() {
	 	 return username; 
	}
	/**
	 * Setter of username
	 */
	public void setUsername(String username) { 
		 this.username = username; 
	}
	/**
	 * Getter of email
	 */
	public String getEmail() {
	 	 return email; 
	}
	/**
	 * Setter of email
	 */
	public void setEmail(String email) { 
		 this.email = email; 
	}
	/**
	 * Getter of password
	 */
	public String getPassword() {
	 	 return password; 
	}
	/**
	 * Setter of password
	 */
	public void setPassword(String password) { 
		 this.password = password; 
	}
	/**
	 * Getter of adminID
	 */
	public String getAdminID() {
	 	 return adminID; 
	}
	/**
	 * Setter of adminID
	 */
	public void setAdminID(String adminID) { 
		 this.adminID = adminID; 
	}
	/**
	 * 
	 */
	public void addproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void updateproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void deleteproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void viewproduct() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void login() { 
		// TODO Auto-generated method
	 } 

}
