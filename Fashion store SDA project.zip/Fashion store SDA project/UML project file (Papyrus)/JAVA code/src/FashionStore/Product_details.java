package FashionStore;

public class Product_details {

	/**
	 * 
	 */
	public String productID;
	/**
	 * 
	 */
	public String product_name;
	public Product product;
	/**
	 * 
	 */
	public String size;
	/**
	 * 
	 */
	public Integer quantity;
	/**
	 * Getter of productID
	 */
	public String getProductID() {
	 	 return productID; 
	}
	/**
	 * Setter of productID
	 */
	public void setProductID(String productID) { 
		 this.productID = productID; 
	}
	/**
	 * Getter of product_name
	 */
	public String getProduct_name() {
	 	 return product_name; 
	}
	/**
	 * Setter of product_name
	 */
	public void setProduct_name(String product_name) { 
		 this.product_name = product_name; 
	}
	/**
	 * Getter of product
	 */
	public Product getProduct() {
	 	 return product; 
	}
	/**
	 * Setter of product
	 */
	public void setProduct(Product product) { 
		 this.product = product; 
	}
	/**
	 * Getter of size
	 */
	public String getSize() {
	 	 return size; 
	}
	/**
	 * Setter of size
	 */
	public void setSize(String size) { 
		 this.size = size; 
	}
	/**
	 * Getter of quantity
	 */
	public Integer getQuantity() {
	 	 return quantity; 
	}
	/**
	 * Setter of quantity
	 */
	public void setQuantity(Integer quantity) { 
		 this.quantity = quantity; 
	}
	/**
	 * 
	 */
	public void chooseproductdetails() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void viewproductdetails() { 
		// TODO Auto-generated method
	 } 

}
