package FashionStore;

public class Review {

	/**
	 * 
	 */
	public String comment;
	/**
	 * 
	 */
	public String username;
	/**
	 * 
	 */
	public String reviewID;
	/**
	 * 
	 */
	public Integer rating;
	/**
	 * Getter of comment
	 */
	public String getComment() {
	 	 return comment; 
	}
	/**
	 * Setter of comment
	 */
	public void setComment(String comment) { 
		 this.comment = comment; 
	}
	/**
	 * Getter of username
	 */
	public String getUsername() {
	 	 return username; 
	}
	/**
	 * Setter of username
	 */
	public void setUsername(String username) { 
		 this.username = username; 
	}
	/**
	 * Getter of reviewID
	 */
	public String getReviewID() {
	 	 return reviewID; 
	}
	/**
	 * Setter of reviewID
	 */
	public void setReviewID(String reviewID) { 
		 this.reviewID = reviewID; 
	}
	/**
	 * Getter of rating
	 */
	public Integer getRating() {
	 	 return rating; 
	}
	/**
	 * Setter of rating
	 */
	public void setRating(Integer rating) { 
		 this.rating = rating; 
	}
	/**
	 * 
	 */
	public void addcomment() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void addreview() { 
		// TODO Auto-generated method
	 } 

}
