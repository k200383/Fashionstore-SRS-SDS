package FashionStore;

public class Cart {

	/**
	 * 
	 */
	public Integer total;
	/**
	 * 
	 */
	public String username;
	/**
	 * 
	 */
	public Product product;
	/**
	 * 
	 */
	public String product_name;
	/**
	 * 
	 */
	public String cartID;
	/**
	 * Getter of total
	 */
	public Integer getTotal() {
	 	 return total; 
	}
	/**
	 * Setter of total
	 */
	public void setTotal(Integer total) { 
		 this.total = total; 
	}
	/**
	 * Getter of username
	 */
	public String getUsername() {
	 	 return username; 
	}
	/**
	 * Setter of username
	 */
	public void setUsername(String username) { 
		 this.username = username; 
	}
	/**
	 * Getter of product
	 */
	public Product getProduct() {
	 	 return product; 
	}
	/**
	 * Setter of product
	 */
	public void setProduct(Product product) { 
		 this.product = product; 
	}
	/**
	 * Getter of product_name
	 */
	public String getProduct_name() {
	 	 return product_name; 
	}
	/**
	 * Setter of product_name
	 */
	public void setProduct_name(String product_name) { 
		 this.product_name = product_name; 
	}
	/**
	 * Getter of cartID
	 */
	public String getCartID() {
	 	 return cartID; 
	}
	/**
	 * Setter of cartID
	 */
	public void setCartID(String cartID) { 
		 this.cartID = cartID; 
	}
	/**
	 * 
	 */
	public void addtocart() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void viewcart() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void removefromcart() { 
		// TODO Auto-generated method
	 } 

}
