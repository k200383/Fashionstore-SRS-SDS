package FashionStore;

public class Order_details {

	/**
	 * 
	 */
	public String orderID;
	/**
	 * 
	 */
	public Cart cart;
	/**
	 * 
	 */
	public Integer subtotal;
	/**
	 * 
	 */
	public Integer shipping;
	/**
	 * 
	 */
	public Integer discount;
	public Integer total;
	/**
	 * Getter of orderID
	 */
	public String getOrderID() {
	 	 return orderID; 
	}
	/**
	 * Setter of orderID
	 */
	public void setOrderID(String orderID) { 
		 this.orderID = orderID; 
	}
	/**
	 * Getter of cart
	 */
	public Cart getCart() {
	 	 return cart; 
	}
	/**
	 * Setter of cart
	 */
	public void setCart(Cart cart) { 
		 this.cart = cart; 
	}
	/**
	 * Getter of subtotal
	 */
	public Integer getSubtotal() {
	 	 return subtotal; 
	}
	/**
	 * Setter of subtotal
	 */
	public void setSubtotal(Integer subtotal) { 
		 this.subtotal = subtotal; 
	}
	/**
	 * Getter of shipping
	 */
	public Integer getShipping() {
	 	 return shipping; 
	}
	/**
	 * Setter of shipping
	 */
	public void setShipping(Integer shipping) { 
		 this.shipping = shipping; 
	}
	/**
	 * Getter of discount
	 */
	public Integer getDiscount() {
	 	 return discount; 
	}
	/**
	 * Setter of discount
	 */
	public void setDiscount(Integer discount) { 
		 this.discount = discount; 
	}
	/**
	 * Getter of total
	 */
	public Integer getTotal() {
	 	 return total; 
	}
	/**
	 * Setter of total
	 */
	public void setTotal(Integer total) { 
		 this.total = total; 
	}
	/**
	 * 
	 */
	public void choose_paymentmethod() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void placeorder() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void view_orderdetails() { 
		// TODO Auto-generated method
	 } 

}
