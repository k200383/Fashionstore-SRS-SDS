package FashionStore;

public class Wishlist {

	/**
	 * 
	 */
	public String wishlistID;
	/**
	 * 
	 */
	public String product_name;
	public Product product;
	/**
	 * 
	 */
	public String username;
	/**
	 * Getter of wishlistID
	 */
	public String getWishlistID() {
	 	 return wishlistID; 
	}
	/**
	 * Setter of wishlistID
	 */
	public void setWishlistID(String wishlistID) { 
		 this.wishlistID = wishlistID; 
	}
	/**
	 * Getter of product_name
	 */
	public String getProduct_name() {
	 	 return product_name; 
	}
	/**
	 * Setter of product_name
	 */
	public void setProduct_name(String product_name) { 
		 this.product_name = product_name; 
	}
	/**
	 * Getter of product
	 */
	public Product getProduct() {
	 	 return product; 
	}
	/**
	 * Setter of product
	 */
	public void setProduct(Product product) { 
		 this.product = product; 
	}
	/**
	 * Getter of username
	 */
	public String getUsername() {
	 	 return username; 
	}
	/**
	 * Setter of username
	 */
	public void setUsername(String username) { 
		 this.username = username; 
	}
	/**
	 * 
	 */
	public void addtowishlist() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void viewwishlist() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void removefromwishlist() { 
		// TODO Auto-generated method
	 } 

}
